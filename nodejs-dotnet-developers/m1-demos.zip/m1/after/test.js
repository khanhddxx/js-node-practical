// test.js
console.log("hello world");

var x = {
  name: "hello",
  birthplace: "world"
};

console.log(x.name + " " + x.birthplace);