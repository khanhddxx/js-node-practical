module.exports = function (){
  this.first = "this is a message";
};