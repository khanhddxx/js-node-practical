// logger/index.js
var file = require("./file");
module.exports.log = function (msg) {
  console.log(msg);
};