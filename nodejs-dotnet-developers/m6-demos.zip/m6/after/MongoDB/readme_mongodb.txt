*********************************
These demo's require MongoDB to be installed and 
the mongod.exe to be in the path. We suggest
installing it into c:\program files\mongodb and
adding that directory to the PATH variable.

Use the startdb.cmd to launch the server before testing this solution. 

You can get MongoDB from http://mongodb.org
